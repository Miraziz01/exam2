let number = +prompt('Sonni kiriting')
let lastname = prompt('Ismizni kiriting')


if (number % 2 === 0) {
    alert('Con')
} else if (number % 2 === 1) {
    alert('Uncon')
} else {
    alert('Error')
}

let text = document.querySelector('.pas')
text.innerHTML = lastname





function com() {
    switch (true) {
        case number % 2 === 0:
            console.log(number + " Com");
            break;
        case number % 2 === 1:
            console.log(number + ' Uncom');
            break;
        default: console.log("Error");
            break;
    }
}

com()